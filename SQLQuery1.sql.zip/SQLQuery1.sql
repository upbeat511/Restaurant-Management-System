
use Project

select * from RESTAURANT
select * from Users


CREATE TABLE Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Email NVARCHAR(100) UNIQUE,
    Password NVARCHAR(100),
    Role NVARCHAR(50)
);

INSERT INTO Users (FirstName, LastName, Email, Password, Role)
VALUES ('Maryyam', 'Tester', 'maryyam@example.com', 'test123', 'inspector');


CREATE TABLE RESTAURANT (
    Restaurant_ID       INT IDENTITY(1,1) PRIMARY KEY,   --column increment 
    Name                VARCHAR(100) NOT NULL,
    Owner_Name          VARCHAR(100),
    Phone_Number        VARCHAR(20),
    Email               VARCHAR(100),
    Address             VARCHAR(200),
    City                VARCHAR(100),
    Zip_Code            VARCHAR(10),
    License_Number      VARCHAR(50),
    Opening_Date        DATE,
    Status              VARCHAR(20) CHECK (Status IN ('Open', 'Closed', 'Suspended')) --allowed status only these 3 
);
ALTER TABLE RESTAURANT
ADD CONSTRAINT UQ_RestaurantName UNIQUE (Name);

SELECT Name, COUNT(*) AS DuplicateCount
FROM RESTAURANT
GROUP BY Name
HAVING COUNT(*) > 1;
UPDATE RESTAURANT
SET Name =  Name+'Dhalia'
WHERE Name = 'Jade'
AND Restaurant_ID NOT IN (
    SELECT MIN(Restaurant_ID)
    FROM RESTAURANT
    WHERE Name = 'Jade'
);
UPDATE RESTAURANT
SET Name = Name + 'Tayto'
WHERE Name = 'JadeDhalia'
AND Restaurant_ID NOT IN (
    SELECT MIN(Restaurant_ID)
    FROM RESTAURANT
    WHERE Name = 'JadeDhalia'
);


select * from RESTAURANT


SELECT Restaurant_ID, Phone_Number
FROM RESTAURANT
WHERE LEN(Phone_Number) <> 11 OR Phone_Number LIKE '%[^0-9]%';


SELECT Restaurant_ID, Zip_Code
FROM RESTAURANT
WHERE LEN(Zip_Code) <> 5 OR Zip_Code LIKE '%[^0-9]%';


SELECT Restaurant_ID, License_Number
FROM RESTAURANT
WHERE LEN(License_Number) <> 4 OR License_Number LIKE '%[^0-9]%';



DBCC CHECKIDENT ('RESTAURANT', RESEED, 0);


ALTER TABLE RESTAURANT
ADD Created_By_Email VARCHAR(100) NULL;


CREATE TABLE DINE_IN_RESTAURANT (
    Restaurant_ID    INT PRIMARY KEY,
    Seating_Capacity INT CHECK (Seating_Capacity > 0),

    FOREIGN KEY (Restaurant_ID) REFERENCES RESTAURANT(Restaurant_ID)
);

CREATE TABLE TAKEAWAY_OUTLET (
    Restaurant_ID       INT PRIMARY KEY,
    Delivery_Available  VARCHAR(3) CHECK (Delivery_Available IN ('Yes','No')),

    FOREIGN KEY (Restaurant_ID) REFERENCES RESTAURANT(Restaurant_ID)
);

CREATE TABLE INSPECTOR (
    Inspector_ID    INT IDENTITY(1,1) PRIMARY KEY,
    First_Name      VARCHAR(100),
    Last_Name       VARCHAR(100),
    Email           VARCHAR(100),
    Phone_Number    VARCHAR(20),
    Region          VARCHAR(50),
    Hire_Date       DATE,
    Designation     VARCHAR(50)
);
CREATE TABLE ROUTINE_INSPECTOR (
    Inspector_ID    INT PRIMARY KEY,
    Assigned_Sector VARCHAR(100),
    Routine_Count   INT DEFAULT 0,

    FOREIGN KEY (Inspector_ID) REFERENCES INSPECTOR(Inspector_ID)
);

CREATE TABLE COMPLAINT_INSPECTOR (
    Inspector_ID     INT PRIMARY KEY,
    Complaint_Area   VARCHAR(100),
    Complaint_Count  INT DEFAULT 0,

    FOREIGN KEY (Inspector_ID) REFERENCES INSPECTOR(Inspector_ID)
);


CREATE TABLE INSPECTION (
    Inspection_ID        INT IDENTITY(1,1) PRIMARY KEY,
    Restaurant_ID        INT NOT NULL,
    Inspector_ID         INT NOT NULL,

    Inspection_Date      DATE NOT NULL,
    Inspection_Time      TIME,
    Inspection_Type      VARCHAR(20) CHECK (Inspection_Type IN ('Routine','Follow-up','Complaint')),
    Score                INT CHECK (Score BETWEEN 0 AND 100),
    Outcome              VARCHAR(20) CHECK (Outcome IN ('Pass','Fail','Conditional')),
    Comments             VARCHAR(MAX),
    Follow_Up_Required   VARCHAR(3) CHECK (Follow_Up_Required IN ('Yes','No')),
    Next_Inspection_Date DATE,

    FOREIGN KEY (Restaurant_ID) REFERENCES RESTAURANT(Restaurant_ID),
    FOREIGN KEY (Inspector_ID) REFERENCES INSPECTOR(Inspector_ID)
);
select * from INSPECTION

ALTER TABLE INSPECTION
ADD CONSTRAINT UQ_RestaurantInspection UNIQUE (Restaurant_ID, Inspection_Date);


CREATE TABLE VIOLATION_CATEGORY (
    Category_ID         INT IDENTITY(1,1) PRIMARY KEY,
    Category_Name       VARCHAR(100),
    Description         VARCHAR(MAX),
    Penalty_Guideline   VARCHAR(MAX)
);

CREATE TABLE VIOLATION (
    Violation_ID       INT IDENTITY(1,1) PRIMARY KEY,
    Inspection_ID      INT NOT NULL,
    Category_ID        INT NOT NULL,

    Violation_Code     VARCHAR(50),
    Description        VARCHAR(MAX),
    Severity           VARCHAR(20) CHECK (Severity IN ('Critical','Non-Critical')) NOT NULL,
    Fine_Amount        DECIMAL(10,2) NOT NULL,
    Corrective_Action  VARCHAR(MAX),
    Resolved_Date      DATE,

    FOREIGN KEY (Inspection_ID) REFERENCES INSPECTION(Inspection_ID),
    FOREIGN KEY (Category_ID) REFERENCES VIOLATION_CATEGORY(Category_ID)
);


CREATE TABLE CRITICAL_VIOLATION (
    Violation_ID         INT PRIMARY KEY,
    Immediate_Action_Required VARCHAR(5) CHECK (Immediate_Action_Required IN ('Yes','No')),

    FOREIGN KEY (Violation_ID) REFERENCES VIOLATION(Violation_ID)
);

CREATE TABLE NON_CRITICAL_VIOLATION (
    Violation_ID     INT PRIMARY KEY,
    Warning_Issued   VARCHAR(3) CHECK (Warning_Issued IN ('Yes','No')),

    FOREIGN KEY (Violation_ID) REFERENCES VIOLATION(Violation_ID)
);


CREATE TRIGGER trg_UpdateScore
ON VIOLATION
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;


    DECLARE @InspectionID INT;

   
    SELECT DISTINCT @InspectionID = Inspection_ID FROM inserted;

 
    IF @InspectionID IS NULL
        SELECT DISTINCT @InspectionID = Inspection_ID FROM deleted;


    UPDATE INSPECTION
    SET Score = 
        100 
        - ISNULL(
            (SELECT SUM(
                CASE 
                    WHEN Severity = 'Critical' THEN 20
                    WHEN Severity = 'Non-Critical' THEN 5
                    ELSE 0
                END)
             FROM VIOLATION
             WHERE Inspection_ID = @InspectionID), 0)
    WHERE Inspection_ID = @InspectionID;
END;
  CREATE TABLE RESTAURANT_ARCHIVE (
    Restaurant_ID INT,
    Name NVARCHAR(100),
    Owner_Name NVARCHAR(100),
    Phone_Number NVARCHAR(50),
    Email NVARCHAR(100),
    Address NVARCHAR(200),
    City NVARCHAR(100),
    Zip_Code NVARCHAR(20),
    License_Number NVARCHAR(50),
    Opening_Date DATE,
    Status NVARCHAR(50),
    Seating_Capacity INT NULL,
    Delivery_Available BIT NULL,
    DeletedOn DATETIME DEFAULT GETDATE()
);
ALTER TABLE RESTAURANT_ARCHIVE ALTER COLUMN Delivery_Available NVARCHAR(10);


INSERT INTO RESTAURANT (Name, Owner_Name, City, Status)
VALUES ('Sunshine Cafe', 'Ali Khan', 'Karachi', 'Open');

INSERT INTO INSPECTOR (First_Name, Last_Name, Email, Region)
VALUES ('Sara', 'Ahmed', 'sara@email.com', 'North');

INSERT INTO VIOLATION_CATEGORY (Category_Name, Description, Penalty_Guideline)
VALUES ('Hygiene', 'Unclean kitchen surfaces', 'Fine 500');

INSERT INTO INSPECTION (Restaurant_ID, Inspector_ID, Inspection_Date, Inspection_Type, Outcome, Follow_Up_Required)
VALUES (2, 1, '2025-11-21', 'Routine', 'Pass', 'No');




INSERT INTO INSPECTION (Restaurant_ID, Inspector_ID, Inspection_Date, Inspection_Type, Outcome, Follow_Up_Required)
VALUES (2, 1, '2025-11-21', 'Routine', 'Pass', 'No');

SELECT * FROM INSPECTION;

INSERT INTO VIOLATION (Inspection_ID, Category_ID, Violation_Code, Description, Severity, Fine_Amount, Corrective_Action)
VALUES (7, 1, 'V003', 'Kitchen Floor Dirty', 'Critical', 300, 'Clean floor immediately');


INSERT INTO VIOLATION (Inspection_ID, Category_ID, Violation_Code, Description, Severity, Fine_Amount, Corrective_Action)
VALUES (7, 1, 'V004', 'Expired Milk', 'Non-Critical', 50, 'Dispose expired milk');




INSERT INTO CRITICAL_VIOLATION (Violation_ID, Immediate_Action_Required)
VALUES (8, 'Yes'); 


INSERT INTO NON_CRITICAL_VIOLATION (Violation_ID, Warning_Issued)
VALUES (7, 'Yes'); 
SELECT * FROM INSPECTION WHERE Inspection_ID = 7;


SELECT * FROM VIOLATION;

SELECT * FROM RESTAURANT;
select * from Users

INSERT INTO RESTAURANT (Name, Owner_Name, Phone_Number, Email, Address, City, Zip_Code, License_Number, Opening_Date, Status)
VALUES ('TestName','TestOwner','123456','test@email.com','TestAddress','TestCity','12345','LIC123','2025-11-28','Open');
select * from RESTAURANT

SELECT * FROM RESTAURANT WHERE Restaurant_ID = 2;
DELETE FROM DINE_IN_RESTAURANT WHERE Restaurant_ID NOT IN (SELECT Restaurant_ID FROM RESTAURANT);
DELETE FROM TAKEAWAY_OUTLET WHERE Restaurant_ID NOT IN (SELECT Restaurant_ID FROM RESTAURANT);
select * from RESTAURANT


SELECT r.Restaurant_ID, r.Name, r.Owner_Name, r.Phone_Number, r.Email, 
       r.Address, r.City, r.Zip_Code, r.License_Number, r.Opening_Date, r.Status,
       d.Seating_Capacity, t.Delivery_Available
FROM RESTAURANT r
LEFT JOIN DINE_IN_RESTAURANT d ON r.Restaurant_ID = d.Restaurant_ID
LEFT JOIN TAKEAWAY_OUTLET t ON r.Restaurant_ID = t.Restaurant_ID

SELECT i.Inspection_ID, i.Restaurant_ID, v.Violation_ID, v.Description
FROM INSPECTION i
LEFT JOIN VIOLATION v ON i.Inspection_ID = v.Inspection_ID
WHERE i.Restaurant_ID = 4;   
select * from RESTAURANT

select * from INSPECTION
select * from INSPECTOR

INSERT INTO INSPECTOR (First_Name, Last_Name, Email, Phone_Number, Region, Hire_Date, Designation)
VALUES ('Ali', 'Khan', 'ali.khan@example.com', '03001234567', 'Lahore', '2025-11-28', 'Routine Inspector');
INSERT INTO INSPECTOR (First_Name, Last_Name, Email, Phone_Number, Region, Hire_Date, Designation)
VALUES ('Zainab', 'Tahir', 'Z.t@example.com', '03001234567', 'Lahore', '2025-11-28', 'Complaint Inspector');


INSERT INTO VIOLATION_CATEGORY (Category_Name, Description, Penalty_Guideline)
VALUES 
('Hygiene', 'Issues related to cleanliness and sanitation', 'Immediate cleaning required'),
('Food Storage', 'Improper storage of food items', 'Discard contaminated food'),
('Staff Training', 'Staff not trained in safety protocols', 'Mandatory retraining'),
('Pest Control', 'Evidence of pests in premises', 'Call pest control service');


ALTER TABLE INSPECTION
ADD CONSTRAINT FK_Inspection_Inspector
FOREIGN KEY (Inspector_ID) REFERENCES USERS(ID);




CREATE PROCEDURE sp_SaveRestaurantt
    @Name NVARCHAR(100),
    @OwnerName NVARCHAR(100),
    @Phone NVARCHAR(20),
    @Email NVARCHAR(100),
    @Address NVARCHAR(200),
    @City NVARCHAR(100),
    @ZipCode NVARCHAR(10),
    @LicenseNumber NVARCHAR(50),
    @OpeningDate DATE,
    @Status NVARCHAR(20),
    @SeatingCapacity INT,
    @DeliveryAvailable VARCHAR(3),
    @ManagerEmail NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    
    IF EXISTS (SELECT 1 FROM RESTAURANT WHERE Name = @Name)
    BEGIN
        RAISERROR('Restaurant name already exists.', 16, 1);
        RETURN;
    END

  
    IF NOT EXISTS (SELECT 1 FROM Users WHERE Email = @ManagerEmail AND Role = 'manager')
    BEGIN
        RAISERROR('Invalid manager.', 16, 1);
        RETURN;
    END

    INSERT INTO RESTAURANT (Name, Owner_Name, Phone_Number, Email, Address, City, Zip_Code,
                            License_Number, Opening_Date, Status, Created_By_Email)
    VALUES (@Name, @OwnerName, @Phone, @Email, @Address, @City, @ZipCode,
            @LicenseNumber, @OpeningDate, @Status, @ManagerEmail);

    DECLARE @NewRestaurantID INT = SCOPE_IDENTITY();

   
    INSERT INTO DINE_IN_RESTAURANT (Restaurant_ID, Seating_Capacity)
    VALUES (@NewRestaurantID, @SeatingCapacity);

    INSERT INTO TAKEAWAY_OUTLET (Restaurant_ID, Delivery_Available)
    VALUES (@NewRestaurantID, @DeliveryAvailable);
END
GO

SELECT name 
FROM sys.objects 
WHERE type = 'P' AND name LIKE 'sp_Save%';


select * From RESTAURANT_ARCHIVE
SELECT * FROM INSPECTION where Inspection_ID=6;


SELECT i.Inspection_ID, i.Restaurant_ID, v.Violation_ID, v.Description
FROM INSPECTION i
LEFT JOIN VIOLATION v ON i.Inspection_ID = v.Inspection_ID
WHERE i.Restaurant_ID = 12; 


SELECT i.Inspection_ID, i.Restaurant_ID, v.Violation_ID, v.Description
FROM INSPECTION i
INNER JOIN VIOLATION v ON i.Inspection_ID = v.Inspection_ID
WHERE i.Restaurant_ID = 12;


SELECT Id FROM Users WHERE Id = 5 AND Role = 'inspector';
  
 ALTER TABLE INSPECTION
DROP CONSTRAINT FK_Inspection_Inspector;

ALTER TABLE INSPECTION
ADD CONSTRAINT FK_Inspection_Inspector
FOREIGN KEY (Inspector_ID) REFERENCES INSPECTOR(Inspector_ID);



  select * from INSPECTION
  select * from VIOLATION

  select * from RESTAURANT
  select * from Users

 
 select * from INSPECTOR


